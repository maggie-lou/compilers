#pragma once

#include <L1.h>

namespace L1{

  void generate_code(Program p);

}
