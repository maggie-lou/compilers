#pragma once

#include <L1.h>

namespace L1{
  Program parse_file (char *fileName);
}
