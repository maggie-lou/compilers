#!/bin/bash

/usr/bin/time ./a.out | awk '{}' 
