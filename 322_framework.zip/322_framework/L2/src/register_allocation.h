#pragma once

#include <L2.h>

using namespace std;

namespace L2{
  void allocate_registers(Function* &f);
}
