#pragma once

#include <L2.h>

using namespace std;

namespace L2{

  void print_vector(vector<string> v);
  void print_function(Function* f);

  extern vector<string> registers;
}
