#pragma once

#include <L2.h>

namespace L2{

  void generate_code(Program p);

}
