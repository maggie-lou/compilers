#pragma once

#include <L3.h>

using namespace std;

namespace L3{

  vector<vector<Instruction*>> generate_contexts(Function* f);

}
