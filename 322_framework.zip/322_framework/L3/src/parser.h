#pragma once

#include <L3.h>
#include <algorithm>

namespace L3{
  Program parse_file (char *fileName);
}
