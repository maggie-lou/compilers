#pragma once

#include <IR.h>

namespace IR{

  void generate_code(Program p);

}
