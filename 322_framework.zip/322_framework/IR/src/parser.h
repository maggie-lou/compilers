#pragma once

#include <IR.h>
#include <algorithm>

namespace IR{
  Program parse_file (char *fileName);
}
